# AmethyX
This is an reupload of Amethyx Receipt Bot from their discord.
# I AM NOT RESPONSIBLE OF HOW YOU ARE GOING TO USE THIS SOFTWARE! 
# THIS IS FOR EDUCATIONAL PURPOSES ONLY! 
I WILL NOT TELL U HOW TO SET IT UP!
# ALL CREDITS GOES TO [AMETHYX DEVS](https://amethyx.net/)
If u want me to take it down messsage me on discord @kilerekk.
